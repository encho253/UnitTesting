﻿namespace PackageManager.Info.Contracts
{
    public interface ILogger
    {
        void Log(string message);
    }
}

﻿using NUnit.Framework;
using System;


namespace PackageManager.Tests.Commands.InstallCommandTest
{
    [TestFixture]
    public class Properties_Should
    {
        [Test]
        public void RightValueSetForTheOperationOfTheInstaller()
        {

        }
    }
}
﻿using Moq;
using NUnit.Framework;
using PackageManager.Commands;
using PackageManager.Models.Contracts;
using System;

namespace PackageManager.Tests.Commands.InstallCommandTest
{
    [TestFixture]
    public class Fields_Should
    {
        [Test]
        public void RightValueSetForTheInstaller()
        {

        }

        [Test]
        public void RightValueSetForThePackage()
        {
            var packageMock = new Mock<IPackage>();
               
        }
    }
}

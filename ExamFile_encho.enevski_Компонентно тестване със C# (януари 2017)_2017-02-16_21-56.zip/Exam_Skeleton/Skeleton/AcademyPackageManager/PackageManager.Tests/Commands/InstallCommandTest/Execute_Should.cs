﻿using NUnit.Framework;

namespace PackageManager.Tests.Commands.InstallCommandTest
{
    [TestFixture]
    public class Execute_Should
    {
        [Test]
        public void ForCallingThePerformOperationFromTheInstaller()
        {

        }
    }
}
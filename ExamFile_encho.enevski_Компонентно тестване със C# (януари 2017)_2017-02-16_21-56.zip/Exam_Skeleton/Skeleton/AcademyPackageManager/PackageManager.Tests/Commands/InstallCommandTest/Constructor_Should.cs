﻿using Moq;
using NUnit.Framework;
using PackageManager.Commands;
using PackageManager.Core.Contracts;
using PackageManager.Models.Contracts;
using System;
using System.Collections.Generic;

namespace PackageManager.Tests.Commands.InstallCommandTest
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenInstallerIsNull()
        {
            var packageMock = new Mock<IPackage>();
            var mock = new Mock<IInstaller<Mock<IPackage>>>();

            Assert.Throws<ArgumentNullException>(() => new InstallCommand(null, packageMock.Object));
        }

        [Test]
        public void ThrowArgumentNullException_WhenPackageIsNull()
        {
            var mockInstaller = new Mock<IInstaller<IPackage>>();
            mockInstaller.Setup(x => x.BasicFolder).Returns("");
            mockInstaller.Setup(x => x.Operation);

            Assert.Throws<ArgumentNullException>(() => new InstallCommand(mockInstaller.Object, null));
        }
    }
}
﻿using Castle.Core.Logging;
using Moq;
using NUnit.Framework;
using PackageManager.Repositories.Contracts;
using PackageManager.Repositories;
using PackageManager.Info;
using PackageManager.Models.Contracts;
using System;
using PackageManager.Models;

namespace PackageManager.Tests.Models.ProjectTest
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void SetPackagesRepositryCorrectly()
        {
            //Arrange and Act
            IRepository<IPackage> packages = null;
            var project = new Project("someName", "Plovdiv", packages);
            var loggerMock = new Mock<ILogger>();

            var expected = new PackageRepository(new Info.ConsoleLogger());

            //Assert
            Assert.AreEqual(expected,project.PackageRepository);         
        }
    }
}
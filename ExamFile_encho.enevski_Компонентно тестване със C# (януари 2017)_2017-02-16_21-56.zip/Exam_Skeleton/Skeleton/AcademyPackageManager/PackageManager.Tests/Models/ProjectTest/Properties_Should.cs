﻿using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using PackageManager.Repositories.Contracts;
using System;

namespace PackageManager.Tests.Models.ProjectTest
{
    [TestFixture]
    public class Properties_Should
    {
        [Test]
        public void SetNameCorrectly()
        {
            //Arrange and Act
            IRepository<IPackage> packages = null;
            var name = "pesho";
            var project = new Project(name, "Plovdiv", packages);


            //Assert
            Assert.AreEqual(name , project.Name);
        }

        [Test]
        public void ThrowArgumentExceptionWhenNameIsNull()
        {
            //Arrange
            IRepository<IPackage> packages = null;
            string name = null;


            //Assert and Act
            Assert.Throws<ArgumentNullException>(() => new Project(name, "Plovdiv", packages));
        }

        [Test]
        public void SetLocationCorrectly()
        {
            //Arrange and Act
            IRepository<IPackage> packages = null;
            var name = "pesho";
            var location = "Plovdiv";
            var project = new Project(name, location, packages);


            //Assert
            Assert.AreEqual(location, project.Location);
        }

        [Test]
        public void ThrowArgumentNullExceptionWhenLocationIsNull()
        {
            //Arrange
            IRepository<IPackage> packages = null;
            string location = null;


            //Assert and Act
            Assert.Throws<ArgumentNullException>(() => new Project("pesho", location, packages));
        }
    }
}
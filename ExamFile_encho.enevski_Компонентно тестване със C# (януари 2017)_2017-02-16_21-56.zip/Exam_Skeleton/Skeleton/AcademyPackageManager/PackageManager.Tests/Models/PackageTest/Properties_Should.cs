﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;

namespace PackageManager.Tests.Models.PackageTest
{
    [TestFixture]
    public class Properties_Should
    {
        [Test]
        public void SetNameCorrectly()
        {
            //Arrange and Act
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            var package = new Package(name, versionMock.Object, null);

            //Assert
            Assert.AreEqual(name, package.Name);
        }

        [Test]
        public void SetVersionCorrectly()
        {
            //Arrange and Act
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.Setup(x => x.Major).Returns(5);

            var package = new Package(name, versionMock.Object, null);

            //Assert
            Assert.AreEqual(versionMock.Object, package.Version);
        }

        [Test]
        public void SetUrlCorrectly()
        {
            //Arrange and Act
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();
            versionMock.Setup(x => x.Major).Returns(5);
            versionMock.Setup(x => x.Minor).Returns(5);
            versionMock.Setup(x => x.Patch).Returns(5);
            versionMock.Setup(x => x.VersionType).Returns(Enums.VersionType.alpha);

            var url = string.Format("{0}.{1}.{2}-{3}", versionMock.Object.Major, versionMock.Object.Minor, versionMock.Object.Patch, versionMock.Object.VersionType);
            var package = new Package(name, versionMock.Object, null);

            //Assert
            Assert.AreEqual(url, package.Url);
        }
    }
}

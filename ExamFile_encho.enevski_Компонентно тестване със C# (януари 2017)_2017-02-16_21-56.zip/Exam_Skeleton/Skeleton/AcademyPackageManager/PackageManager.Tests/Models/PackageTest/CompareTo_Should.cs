﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;


namespace PackageManager.Tests.Models.PackageTest
{
    [TestFixture]
    public class CompareTo_Should
    {
        [Test]
        public void ThrowArgumentNullException_WhenOtherIsInvalid()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();
        
            versionMock.Setup(x => x.Major).Returns(5);

            var package = new Package(name, versionMock.Object, null);

            //Assert
            Assert.Throws<ArgumentNullException>(() => package.CompareTo(null));
        }

        [Test]
        public void DoesNotThrowException_WhenOtherIsValid()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            versionMock.Setup(x => x.Major).Returns(5);

            var package = new Package(name, versionMock.Object, null);

            //Assert
            Assert.DoesNotThrow(() => package.CompareTo(package));
        }

        [Test]
        public void ThrowException_WhenPassedPackageIsNotWithTheSameName()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();
            var packageMock = new Mock<IPackage>();
            packageMock.Setup(x => x.Name).Returns("Gosho");
            versionMock.Setup(x => x.Major).Returns(5);

            var package = new Package(name, versionMock.Object, null);

            //Assert and Act
            Assert.Throws<ArgumentException>(() => package.CompareTo(packageMock.Object));
        }

        [Test]
        public void PackagePassedToBeHigherVersion()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            versionMock.Setup(x => x.Major).Returns(5);
            versionMock.Setup(x => x.Minor).Returns(5);
            versionMock.Setup(x => x.Patch).Returns(5);
            versionMock.Setup(x => x.VersionType).Returns(Enums.VersionType.alpha);


            var packageMock = new Mock<IPackage>();
            packageMock.Setup(x => x.Name).Returns("Pesho");
            packageMock.Setup(x => x.Version.Major).Returns(4);
            packageMock.Setup(x => x.Version.Minor).Returns(4);
            packageMock.Setup(x => x.Version.Patch).Returns(4);
            packageMock.Setup(x => x.Version.VersionType).Returns(Enums.VersionType.alpha);

            var package = new Package(name, versionMock.Object, null);

            //Assert and Act
            var result = package.CompareTo(packageMock.Object);

            Assert.AreEqual(result, 1);
        }

        [Test]
        public void PackagePassedToBeLowerVersion()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            versionMock.Setup(x => x.Major).Returns(5);
            versionMock.Setup(x => x.Minor).Returns(5);
            versionMock.Setup(x => x.Patch).Returns(5);
            versionMock.Setup(x => x.VersionType).Returns(Enums.VersionType.alpha);


            var packageMock = new Mock<IPackage>();
            packageMock.Setup(x => x.Name).Returns("Pesho");
            packageMock.Setup(x => x.Version.Major).Returns(10);
            packageMock.Setup(x => x.Version.Minor).Returns(4);
            packageMock.Setup(x => x.Version.Patch).Returns(4);
            packageMock.Setup(x => x.Version.VersionType).Returns(Enums.VersionType.alpha);

            var package = new Package(name, versionMock.Object, null);

            //Assert and Act
            var result = package.CompareTo(packageMock.Object);

            Assert.AreEqual(result, -1);
        }

        [Test]
        public void PackagePassedToBeTheSameVersion()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            versionMock.Setup(x => x.Major).Returns(5);
            versionMock.Setup(x => x.Minor).Returns(5);
            versionMock.Setup(x => x.Patch).Returns(5);
            versionMock.Setup(x => x.VersionType).Returns(Enums.VersionType.alpha);


            var packageMock = new Mock<IPackage>();
            packageMock.Setup(x => x.Name).Returns("Pesho");
            packageMock.Setup(x => x.Version.Major).Returns(5);
            packageMock.Setup(x => x.Version.Minor).Returns(5);
            packageMock.Setup(x => x.Version.Patch).Returns(5);
            packageMock.Setup(x => x.Version.VersionType).Returns(Enums.VersionType.alpha);

            var package = new Package(name, versionMock.Object, null);

            //Assert and Act
            var result = package.CompareTo(packageMock.Object);

            Assert.AreEqual(result, 0);
        }
    }
}
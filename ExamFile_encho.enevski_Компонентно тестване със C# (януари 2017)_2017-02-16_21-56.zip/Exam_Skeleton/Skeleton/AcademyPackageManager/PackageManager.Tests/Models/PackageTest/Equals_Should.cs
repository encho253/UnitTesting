﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;
using System;

namespace PackageManager.Tests.Models.PackageTest
{
    [TestFixture]
    public class Equals_Should
    {
        [Test]
        public void ThrowException_WhenPassedObjectIsNull()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();                   

            var package = new Package(name, versionMock.Object, null);
            object obj = null;

            //Assert and Act          
            Assert.Throws<ArgumentNullException>(() => package.Equals(obj));          
        }

        [Test]
        public void ThrowException_WhenPassedValueIsNotIPackage()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();
            var packageMock = new Mock<IVersion>();
            
            var package = new Package(name, versionMock.Object, null);
            var obj = packageMock.Object;

            //Assert and Act          
            Assert.Throws<ArgumentException>(() => package.Equals(obj));
        }

        [Test]
        public void DoesNotThrowException_WhenPassedValueIsIPackage()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();
            var packageMock = new Mock<IPackage>();

           
            var package = new Package(name, versionMock.Object, null);
            var obj = packageMock.Object;

            //Assert and Act          
            Assert.DoesNotThrow(() => package.Equals(obj));
        }

        [Test]
        public void PackagePassedToBeEqualToThePackage()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();  

            versionMock.Setup(x => x.Major).Returns(5);
            versionMock.Setup(x => x.Minor).Returns(5);
            versionMock.Setup(x => x.Patch).Returns(5);
            versionMock.Setup(x => x.VersionType).Returns(Enums.VersionType.alpha);


            var packageMock = new Mock<IPackage>();
            packageMock.Setup(x => x.Name).Returns("Pesho");
            packageMock.Setup(x => x.Version.Major).Returns(5);
            packageMock.Setup(x => x.Version.Minor).Returns(5);
            packageMock.Setup(x => x.Version.Patch).Returns(5);
            packageMock.Setup(x => x.Version.VersionType).Returns(Enums.VersionType.alpha);

            var package = new Package(name, versionMock.Object, null);
            var obj = packageMock.Object;

            //Assert and Act          
            package.Equals(obj);

            Assert.AreEqual(obj.Name,package.Name);
            Assert.AreEqual(obj.Version.Major, package.Version.Major);
            Assert.AreEqual(obj.Version.Minor, package.Version.Minor);
            Assert.AreEqual(obj.Version.Patch, package.Version.Patch);
            Assert.AreEqual(obj.Version.VersionType, package.Version.VersionType);
        }

        [Test]
        public void PackagePassedToBeNotEqualToThePackage()
        {
            //Arrange 
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();

            versionMock.Setup(x => x.Major).Returns(5);
            versionMock.Setup(x => x.Minor).Returns(5);
            versionMock.Setup(x => x.Patch).Returns(5);
            versionMock.Setup(x => x.VersionType).Returns(Enums.VersionType.alpha);


            var packageMock = new Mock<IPackage>();
            packageMock.Setup(x => x.Name).Returns("Pesh");
            packageMock.Setup(x => x.Version.Major).Returns(2);
            packageMock.Setup(x => x.Version.Minor).Returns(2);
            packageMock.Setup(x => x.Version.Patch).Returns(1);
            packageMock.Setup(x => x.Version.VersionType).Returns(Enums.VersionType.rc);

            var package = new Package(name, versionMock.Object, null);
            var obj = packageMock.Object;

            //Assert and Act          
            package.Equals(obj);

            Assert.AreNotEqual(obj.Name, package.Name);
            Assert.AreNotEqual(obj.Version.Major, package.Version.Major);
            Assert.AreNotEqual(obj.Version.Minor, package.Version.Minor);
            Assert.AreNotEqual(obj.Version.Patch, package.Version.Patch);
            Assert.AreNotEqual(obj.Version.VersionType, package.Version.VersionType);
        }
    }
}
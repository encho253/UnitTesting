﻿using Moq;
using NUnit.Framework;
using PackageManager.Models;
using PackageManager.Models.Contracts;

namespace PackageManager.Tests.Models.PackageTest
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void NameSetCorrectly()
        {
            //Arrange and Act
            var name = "Pesho";
            var versionMock = new Mock<IVersion>();
                       
            var package = new Package(name, versionMock.Object, null);

            var dependencies = package.Dependencies;
 
            //Assert
        }
    }
}
﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;

namespace PackageManager.Tests.Models.PackageVersionTests
{
    [TestFixture]
    public class Constructor_Should
    {
        [Test]
        public void SetsSuccessfullyMajorValue()
        {
            //Arrange and Act
            int major = 10;
            int minor = 5;
            int patch = 15;
             
            var packageVersion = new PackageVersion(major, minor, patch, VersionType.beta);

            //Assert
            Assert.AreEqual(major , packageVersion.Major);
        }

        [Test]
        public void SetsSuccessfullyMinorValue()
        {
            //Arrange and Act
            int major = 10;
            int minor = 5;
            int patch = 15;

            var packageVersion = new PackageVersion(major, minor, patch, VersionType.beta);

            //Assert
            Assert.AreEqual(minor, packageVersion.Minor);
        }

        [Test]
        public void SetsSuccessfullyPatchValue()
        {
            //Arrange and Act
            int major = 10;
            int minor = 5;
            int patch = 15;

            var packageVersion = new PackageVersion(major, minor, patch, VersionType.beta);

            //Assert
            Assert.AreEqual(patch, packageVersion.Patch);
        }

        [Test]
        public void SetsSuccessfullyVersionTypeEnumValue()
        {
            //Arrange and Act
            int major = 10;
            int minor = 5;
            int patch = 15;
            var enumType = VersionType.beta;

            var packageVersion = new PackageVersion(major, minor, patch, enumType);

            //Assert
            Assert.AreEqual(enumType, packageVersion.VersionType);
        }
    }
}
﻿using NUnit.Framework;
using PackageManager.Enums;
using PackageManager.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Models.PackageVersionTests
{
    [TestFixture]
    public class Properties_Should
    {
        [Test]
        public void MajorThrowArgumentException_WhenPassedValueIsInvalid()
        {
            //Arrange
            int major = -1;
            int minor = 5;
            int patch = 15;

            //Act and Assert     
            Assert.Throws<ArgumentException>(() => new PackageVersion(major, minor, patch, VersionType.beta));     
        }

        [Test]
        public void MajorShouldSetPassedValueSuccessfully()
        {
            //Arrange
            int major = 1;
            int minor = 5;
            int patch = 15;

            //Act and Assert     
            Assert.DoesNotThrow(() => new PackageVersion(major, minor, patch, VersionType.beta));
        }

        [Test]
        public void MinorThrowArgumentException_WhenPassedValueIsInvalid()
        {
            //Arrange
            int major = 1;
            int minor = -5;
            int patch = 15;

            //Act and Assert     
            Assert.Throws<ArgumentException>(() => new PackageVersion(major, minor, patch, VersionType.beta));
        }

        [Test]
        public void MinorShouldSetPassedValueSuccessfully()
        {
            //Arrange
            int major = 1;
            int minor = 5;
            int patch = 15;

            //Act and Assert     
            Assert.DoesNotThrow(() => new PackageVersion(major, minor, patch, VersionType.beta));
        }

        [Test]
        public void PatchThrowArgumentException_WhenPassedValueIsInvalid()
        {
            //Arrange
            int major = 1;
            int minor = 5;
            int patch = -15;

            //Act and Assert     
            Assert.Throws<ArgumentException>(() => new PackageVersion(major, minor, patch, VersionType.beta));
        }

        [Test]
        public void PatchShouldSetPassedValueSuccessfully()
        {
            //Arrange
            int major = 1;
            int minor = 5;
            int patch = 15;

            //Act and Assert     
            Assert.DoesNotThrow(() => new PackageVersion(major, minor, patch, VersionType.beta));
        }
      
        [Test]
        public void VersionTypeShouldSetPassedValueSuccessfully()
        {
            //Arrange
            int major = 1;
            int minor = 5;
            int patch = 15;

            //Act and Assert     
            Assert.DoesNotThrow(() => new PackageVersion(major, minor, patch, VersionType.beta));
        }
    }
}

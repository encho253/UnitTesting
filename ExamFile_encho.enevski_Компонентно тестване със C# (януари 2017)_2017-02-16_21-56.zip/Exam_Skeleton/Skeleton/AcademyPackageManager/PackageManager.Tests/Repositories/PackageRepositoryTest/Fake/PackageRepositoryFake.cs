﻿using System.Collections.Generic;
using PackageManager.Info.Contracts;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;

namespace PackageManager.Tests.Repositories.PackageRepositoryTest.Fake
{
    internal class PackageRepositoryFake : PackageRepository
    {
        public PackageRepositoryFake(ILogger logger, ICollection<IPackage> packages = null) 
            : base(logger, packages)
        {
        }

        public ICollection<IPackage> Packages
        {
            get
            {
                return this.packages;
            }
        }

        public ILogger Logger
        {
            get
            {
                return this.logger;
            }
        }
    }
}

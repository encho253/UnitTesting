﻿using Moq;
using NUnit.Framework;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using PackageManager.Tests.Repositories.PackageRepositoryTest.Fake;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories.PackageRepositoryTest
{
    [TestFixture]
    public class Upadate_Should
    {
        [Test]
        public void ForValidAndInvalidValuePackage()
        {
            var loggerMock = new Mock<Info.Contracts.ILogger>();

            var packageRepo = new PackageRepository(loggerMock.Object, null);

            Assert.Throws<ArgumentNullException>(() => packageRepo.Update(null));
        }

        [Test]
        public void ThrowArgumentNullExceptionWhenThePackageDoesNotExist()
        {
            var loggerMock = new Mock<Info.Contracts.ILogger>();
            var packageMock = new Mock<IPackage>();
            var packageRepo = new PackageRepositoryFake(loggerMock.Object, null);

            Assert.Throws<ArgumentNullException>(() => packageRepo.Update(packageMock.Object));
        }
    }
}

﻿using Moq;
using NUnit.Framework;
using PackageManager.Repositories;
using PackageManager.Info.Contracts;
using System;
using PackageManager.Models.Contracts;
using PackageManager.Tests.Repositories.PackageRepositoryTest.Fake;
using System.Collections.Generic;
using System.Linq;

namespace PackageManager.Tests.Repositories.PackageRepositoryTest
{
    [TestFixture]
    public class Add_Should
    {
        [Test]
        public void ForInvaledValuePAckage_ThrowArgumentNullException()
        {
            var loggerMock = new Mock<ILogger>();

            var packageRepo = new PackageRepository(loggerMock.Object, null);


            Assert.Throws<ArgumentNullException>(() => packageRepo.Add(null));
        }

        [Test]
        public void AddingThePackageWhenThePackageDoesNotExist()
        {
            var loggerMock = new Mock<ILogger>();
            var packageMock = new Mock<IPackage>();
            var packageRepo = new PackageRepositoryFake(loggerMock.Object, null);

            packageRepo.Add(packageMock.Object);

            Assert.AreEqual(packageRepo.Packages.Count , 1);
        }

        [Test]
        public void TestForPackageAlreadyExistWithTheSameVersion()
        {
            var logger = new Mock<ILogger>();
            var packageMock = new Mock<IPackage>();         
            var collection = new List<IPackage>();

            packageMock.Setup(x => x.Name).Returns("Pesho");
            collection.Add(packageMock.Object);

            var packageRepo = new PackageRepositoryFake(logger.Object, collection);
            packageRepo.Add(packageMock.Object);

            //Assert.AreEqual(packageRepo.Logger,Times.AtLeastOnce());

        }

        [Test]
        public void ForCallingTheUpdateMethodWhenThePackageExistButWithLowerVersion()
        {
            var logger = new Mock<ILogger>();
            var packageMock = new Mock<IPackage>();
            var packageMock2 = new Mock<IPackage>();
            var collection = new List<IPackage>();

            packageMock.Setup(x => x.Name).Returns("Pesho");
            collection.Add(packageMock.Object);

            packageMock2.Setup(x => x.Name).Returns("Pesho");

            var packageRepo = new PackageRepositoryFake(logger.Object, collection);
            packageRepo.Add(packageMock2.Object);

        }
    }
}
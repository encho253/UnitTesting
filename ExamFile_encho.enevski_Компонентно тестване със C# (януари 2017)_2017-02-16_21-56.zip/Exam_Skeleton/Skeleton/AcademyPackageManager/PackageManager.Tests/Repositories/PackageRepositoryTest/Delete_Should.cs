﻿using Moq;
using NUnit.Framework;
using PackageManager.Models.Contracts;
using PackageManager.Repositories;
using PackageManager.Tests.Repositories.PackageRepositoryTest.Fake;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories.PackageRepositoryTest
{
    [TestFixture]
    public class Delete_Should
    {
        [Test]
        public void  ForValidAndInvalidValuePackage()
        {
            var loggerMock = new Mock<Info.Contracts.ILogger>();

            var packageRepo = new PackageRepository(loggerMock.Object, null);

            Assert.Throws<ArgumentNullException>(() => packageRepo.Delete(null));
        }

        [Test]
        public void ThrowArgumentNullExceptionWhenThePackageDoesNotExist()
        {
            var loggerMock = new Mock<Info.Contracts.ILogger>();
            var packageMock = new Mock<IPackage>();
            var packageRepo = new PackageRepositoryFake(loggerMock.Object, null);

            Assert.Throws<ArgumentNullException>(() => packageRepo.Delete(packageMock.Object));
        }
    }
}
﻿using Moq;
using NUnit.Framework;
using PackageManager.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageManager.Tests.Repositories.PackageRepositoryTest
{
    [TestFixture]
    public class GetAll_Should
    {
        [Test]
        public void NoPassedCollectionToReturnAsParameterEmptyCollection()
        {
            var loggerMock = new Mock<Info.Contracts.ILogger>();

            var packageRepo = new PackageRepository(loggerMock.Object, null);

            packageRepo.GetAll();
        }
    }
}
